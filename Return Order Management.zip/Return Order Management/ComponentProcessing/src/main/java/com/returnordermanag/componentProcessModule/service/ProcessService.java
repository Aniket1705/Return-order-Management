package com.returnordermanag.componentProcessModule.service;

import com.returnordermanag.componentProcessModule.model.ProcessResponse;

public interface ProcessService {
	ProcessResponse processDetail(int userID);
}
