insert into process_request values (1, 'Earphones', 'accessory', 9654388404, 12345678912345678, true, 1, 'Mrunal');
insert into process_request values (2, 'Charger', 'accessory', 9654388404, 12345678912345678, false, 2, 'Abhishek');
insert into process_request values (3, 'Mobile', 'integral', 9654388404, 12345678912345678, true, 3, 'Satyam');
insert into process_request values (4, 'Laptop', 'integral', 9654388404, 12345678912345678, false, 1, 'Harivivek');
insert into process_request values (5, 'Camera', 'accessory', 9654388404, 12345678912345678, true, 4, 'Aniket');
